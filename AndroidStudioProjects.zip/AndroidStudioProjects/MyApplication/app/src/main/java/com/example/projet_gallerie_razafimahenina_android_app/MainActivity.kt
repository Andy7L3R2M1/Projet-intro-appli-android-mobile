package com.example.projet_gallerie_razafimahenina_android_app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MessageCard(
                msg = Message("La Grande Vague de Kanagawa", "Hokusai", "(1830-1831)")
            )
        }
    }
}
data class Message(val title: String, val author: String, val annee : String)

@Composable
fun MessageCard(msg: Message) {

    Column {
        Image(
            painter = painterResource(R.drawable.p1),
            contentDescription = "Contact profile picture",
            modifier = Modifier
                // Set image size to x dp
                .size(350.dp)
                // Clip image to be shaped as a circle
                .clip(RectangleShape)
                .align(CenterHorizontally)
        )

        // Add a horizontal space between the image and the column
        Spacer(modifier = Modifier.height(1.dp))

        // Add padding around our message
        Column {
            Surface(shape = MaterialTheme.shapes.medium, elevation = 1.dp, modifier = Modifier.fillMaxSize()) {
                Text(
                    text = msg.title,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Normal,
                    fontStyle = FontStyle.Italic
                )
                Spacer(modifier = Modifier.height(25.dp))

                 Row{
                    Text(
                        text = msg.author,
                        fontWeight = FontWeight.Bold
                    )

                    // Add an horizontal space between the author and message texts
                    Spacer(modifier = Modifier.width(10.dp))

                    Text(
                        text = msg.annee,
                        fontWeight = FontWeight.Normal
                    )
                }
            }
        }

    }
}

@Preview(showBackground = true)
@Composable
fun PreviewMessageCard() {
    MessageCard(
        msg = Message("La Grande Vague de Kanagawa", "Hokusai", "(1830-1831)")
    )
}
